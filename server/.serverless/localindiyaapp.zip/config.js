module.exports = {
    aws_table_name: 'dynamodb-test',
    aws_local_config: {
      //Provide details for local configuration
    },
    aws_remote_config: {
      accessKeyId: 'AKIASZTWQ7KUNNJL5LHE',
      secretAccessKey: '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',
      region: 'us-east-1',
    }
};